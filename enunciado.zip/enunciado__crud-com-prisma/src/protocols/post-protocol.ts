export type ApplicationError = {
  name: string;
  message: string;
};